package com.hostelfood.ui;

import javax.swing.*;
import java.awt.*;

public class FeedbackFrame extends JFrame {

    private JComboBox<String> mealComboBox;
    private JSpinner qualitySpinner;
    private JSpinner tasteSpinner;
    private JSpinner hygieneSpinner;
    private JTextArea commentsArea;

    private JButton feedbackButton;

    public FeedbackFrame(String selectedMeal, JButton feedbackButton) {

        this.feedbackButton = feedbackButton;

        setTitle("Hostel Food Feedback - Submit Feedback");
        setSize(600, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(25, 35, 25, 35)
        );
        mainPanel.setBackground(new Color(245, 247, 250));

        JLabel titleLabel = new JLabel("Submit Food Feedback");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 26));
        titleLabel.setForeground(new Color(31, 78, 121));

        JLabel subtitleLabel = new JLabel(
                "Please rate today's hostel food"
        );
        subtitleLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(
                new BoxLayout(headerPanel, BoxLayout.Y_AXIS)
        );
        headerPanel.setOpaque(false);

        headerPanel.add(titleLabel);
        headerPanel.add(Box.createVerticalStrut(5));
        headerPanel.add(subtitleLabel);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        );

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;

        formPanel.add(new JLabel("Meal:"), gbc);

        mealComboBox = new JComboBox<>(
                new String[]{"Breakfast", "Lunch", "Dinner"}
        );

        if (selectedMeal != null) {
            mealComboBox.setSelectedItem(selectedMeal);
        }

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(mealComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy++;

        formPanel.add(
                new JLabel("Food Quality (1-5):"),
                gbc
        );

        qualitySpinner = createRatingSpinner();

        gbc.gridx = 1;

        formPanel.add(qualitySpinner, gbc);

        gbc.gridx = 0;
        gbc.gridy++;

        formPanel.add(
                new JLabel("Taste (1-5):"),
                gbc
        );

        tasteSpinner = createRatingSpinner();

        gbc.gridx = 1;

        formPanel.add(tasteSpinner, gbc);

        gbc.gridx = 0;
        gbc.gridy++;

        formPanel.add(
                new JLabel("Hygiene (1-5):"),
                gbc
        );

        hygieneSpinner = createRatingSpinner();

        gbc.gridx = 1;

        formPanel.add(hygieneSpinner, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.NORTH;

        formPanel.add(
                new JLabel("Comments:"),
                gbc
        );

        commentsArea = new JTextArea(7, 25);
        commentsArea.setLineWrap(true);
        commentsArea.setWrapStyleWord(true);
        commentsArea.setFont(
                new Font("SansSerif", Font.PLAIN, 14)
        );

        JScrollPane scrollPane =
                new JScrollPane(commentsArea);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1;

        formPanel.add(scrollPane, gbc);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel =
                new JPanel(new FlowLayout(FlowLayout.RIGHT));

        buttonPanel.setOpaque(false);

        JButton cancelButton =
                new JButton("Cancel");

        JButton submitButton =
                new JButton("Submit Feedback");

        cancelButton.setPreferredSize(
                new Dimension(100, 38)
        );

        submitButton.setPreferredSize(
                new Dimension(160, 38)
        );

        cancelButton.addActionListener(e -> dispose());

        submitButton.addActionListener(
                e -> submitFeedback()
        );

        buttonPanel.add(cancelButton);
        buttonPanel.add(submitButton);

        mainPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        add(mainPanel);

        setVisible(true);
    }

    private JSpinner createRatingSpinner() {

        SpinnerNumberModel model =
                new SpinnerNumberModel(
                        3,
                        1,
                        5,
                        1
                );

        JSpinner spinner =
                new JSpinner(model);

        spinner.setPreferredSize(
                new Dimension(80, 30)
        );

        return spinner;
    }

    private void submitFeedback() {

        String meal =
                (String) mealComboBox.getSelectedItem();

        int quality =
                (int) qualitySpinner.getValue();

        int taste =
                (int) tasteSpinner.getValue();

        int hygiene =
                (int) hygieneSpinner.getValue();

        String comments =
                commentsArea.getText().trim();

        JOptionPane.showMessageDialog(
                this,
                "Feedback submitted successfully!\n\n"
                        + "Meal: " + meal + "\n"
                        + "Food Quality: " + quality + "/5\n"
                        + "Taste: " + taste + "/5\n"
                        + "Hygiene: " + hygiene + "/5",
                "Feedback Submitted",
                JOptionPane.INFORMATION_MESSAGE
        );

        feedbackButton.setText("Feedback Submitted ✓");
        feedbackButton.setEnabled(false);

        dispose();
    }
}