package com.hostelfood.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class LoginFrame extends JFrame {

    private final JTextField studentIdField = new JTextField();
    private final JPasswordField passwordField = new JPasswordField();
    private final JComboBox<String> roleBox = new JComboBox<>(
            new String[]{"Student", "Committee Leader", "Caretaker"}
    );

    public LoginFrame() {
        setTitle("Hostel Food Feedback System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 560);
        setLocationRelativeTo(null);
        setResizable(false);

        buildUI();
        setVisible(true);
    }

    private void buildUI() {
        JPanel root = new JPanel(new GridLayout(1, 2));
        root.setBackground(new Color(245, 247, 250));

        // Left branding panel
        JPanel branding = new JPanel();
        branding.setBackground(new Color(31, 78, 121));
        branding.setLayout(new BoxLayout(branding, BoxLayout.Y_AXIS));
        branding.setBorder(new EmptyBorder(60, 45, 60, 45));

        JLabel icon = new JLabel("★");
        icon.setFont(new Font("SansSerif", Font.BOLD, 42));
        icon.setForeground(Color.WHITE);
        icon.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("<html><div style='width:300px'>Hostel Food<br>Feedback System</div></html>");
        title.setFont(new Font("SansSerif", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel(
                "<html><div style='width:300px'>Rate your hostel meals, report food issues,<br>"
                        + "and help improve the mess experience.</div></html>"
        );
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 15));
        subtitle.setForeground(new Color(225, 235, 245));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        branding.add(icon);
        branding.add(Box.createVerticalStrut(25));
        branding.add(title);
        branding.add(Box.createVerticalStrut(18));
        branding.add(subtitle);
        branding.add(Box.createVerticalGlue());

        JLabel footer = new JLabel("Java Swing • Frontend");
        footer.setFont(new Font("SansSerif", Font.PLAIN, 12));
        footer.setForeground(new Color(205, 220, 235));
        footer.setAlignmentX(Component.LEFT_ALIGNMENT);
        branding.add(footer);

        // Right login panel
        JPanel loginArea = new JPanel(new GridBagLayout());
        loginArea.setBackground(Color.WHITE);

        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(20, 35, 20, 35));
        card.setPreferredSize(new Dimension(360, 400));

        JLabel welcome = new JLabel("Welcome back");
        welcome.setFont(new Font("SansSerif", Font.BOLD, 26));
        welcome.setForeground(new Color(35, 35, 35));
        welcome.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel instruction = new JLabel("Sign in to continue");
        instruction.setFont(new Font("SansSerif", Font.PLAIN, 14));
        instruction.setForeground(new Color(110, 110, 110));
        instruction.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(welcome);
        card.add(Box.createVerticalStrut(6));
        card.add(instruction);
        card.add(Box.createVerticalStrut(28));

        addField(card, "Student / User ID", studentIdField);
        card.add(Box.createVerticalStrut(15));
        addField(card, "Password", passwordField);
        card.add(Box.createVerticalStrut(15));
        addField(card, "Login as", roleBox);
        card.add(Box.createVerticalStrut(25));

        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("SansSerif", Font.BOLD, 15));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(31, 78, 121));
        loginButton.setFocusPainted(false);
        loginButton.setBorderPainted(false);
        loginButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        loginButton.addActionListener(e -> handleLogin());

        card.add(loginButton);
        card.add(Box.createVerticalStrut(16));

        JLabel demo = new JLabel("<html><center>Demo: STU001 / 1234</center></html>");
        demo.setFont(new Font("SansSerif", Font.PLAIN, 12));
        demo.setForeground(new Color(130, 130, 130));
        demo.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(demo);

        loginArea.add(card);
        root.add(branding);
        root.add(loginArea);

        setContentPane(root);

        getRootPane().setDefaultButton(loginButton);
    }

    private void addField(JPanel panel, String labelText, JComponent field) {
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("SansSerif", Font.BOLD, 13));
        label.setForeground(new Color(65, 65, 65));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setFont(new Font("SansSerif", Font.PLAIN, 14));
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        panel.add(label);
        panel.add(Box.createVerticalStrut(6));
        panel.add(field);
    }

    private void handleLogin() {
        String userId = studentIdField.getText().trim();
        String password = new String(passwordField.getPassword());
        String role = (String) roleBox.getSelectedItem();

        if (userId.isEmpty()) {
            showError("Please enter your User ID.");
            studentIdField.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            showError("Please enter your password.");
            passwordField.requestFocus();
            return;
        }

        // Temporary frontend-only authentication.
        // Replace this section with backend authentication later.
        if (userId.equals("STU001") && password.equals("1234")) {
            JOptionPane.showMessageDialog(
                    this,
                    "Login successful as " + role + ".",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

            // Next screen will be connected here.
            if ("Student".equals(role)) {
              new StudentDashboard(userId);
            } else if ("Committee Leader".equals(role)) {
                new CommitteeDashboard();
            } else {
                new CaretakerDashboard();
            }
            dispose();
        } else {
            showError("Invalid User ID or password.");
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Login Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
