package com.hostelfood.ui;

import javax.swing.*;
import java.awt.*;

public class CommitteeDashboard extends JFrame {
    public CommitteeDashboard() {
        setTitle("Committee Leader Dashboard");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel label = new JLabel("Committee Leader Dashboard — Next screen", SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(label);

        setVisible(true);
    }
}
