package com.hostelfood.ui;

import javax.swing.*;
import java.awt.*;

public class StudentDashboard extends JFrame {

    private JButton breakfastButton;
    private JButton lunchButton;
    private JButton dinnerButton;

    public StudentDashboard(String studentName) {

        setTitle("Hostel Food Feedback System - Student Dashboard");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(20, 20));
        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(25, 35, 25, 35)
        );
        mainPanel.setBackground(new Color(245, 247, 250));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(31, 78, 121));
        headerPanel.setBorder(
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        JLabel title = new JLabel("Student Dashboard");
        title.setFont(new Font("SansSerif", Font.BOLD, 28));
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel(
                "Hostel Food Quality Feedback System"
        );
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
        subtitle.setForeground(Color.WHITE);

        JLabel studentInfo = new JLabel(
                "Student: " + studentName + "    |    Date: 30-09-2026"
        );
        studentInfo.setFont(new Font("SansSerif", Font.PLAIN, 14));
        studentInfo.setForeground(Color.WHITE);

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(
                new BoxLayout(titlePanel, BoxLayout.Y_AXIS)
        );
        titlePanel.setOpaque(false);

        titlePanel.add(title);
        titlePanel.add(Box.createVerticalStrut(5));
        titlePanel.add(subtitle);
        titlePanel.add(Box.createVerticalStrut(5));
        titlePanel.add(studentInfo);

        headerPanel.add(titlePanel, BorderLayout.WEST);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(
                new GridLayout(1, 3, 20, 20)
        );
        centerPanel.setOpaque(false);

        centerPanel.add(
                createMealCard(
                        "Breakfast",
                        "Give feedback for today's breakfast"
                )
        );

        centerPanel.add(
                createMealCard(
                        "Lunch",
                        "Give feedback for today's lunch"
                )
        );

        centerPanel.add(
                createMealCard(
                        "Dinner",
                        "Give feedback for today's dinner"
                )
        );

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(
                new FlowLayout(FlowLayout.RIGHT)
        );
        bottomPanel.setOpaque(false);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(
                new Font("SansSerif", Font.BOLD, 14)
        );
        logoutButton.setPreferredSize(
                new Dimension(110, 38)
        );

        logoutButton.addActionListener(e -> {
            dispose();
            new LoginFrame();
        });

        bottomPanel.add(logoutButton);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);

        setVisible(true);
    }

    private JPanel createMealCard(
            String mealName,
            String description
    ) {

        JPanel card = new JPanel();

        card.setLayout(
                new BoxLayout(card, BoxLayout.Y_AXIS)
        );

        card.setBackground(Color.WHITE);

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(220, 220, 220)
                        ),
                        BorderFactory.createEmptyBorder(
                                25, 20, 25, 20
                        )
                )
        );

        JLabel mealLabel = new JLabel(mealName);
        mealLabel.setFont(
                new Font("SansSerif", Font.BOLD, 22)
        );
        mealLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        JLabel descriptionLabel = new JLabel(
                "<html><div style='text-align:center;'>"
                        + description
                        + "</div></html>"
        );

        descriptionLabel.setFont(
                new Font("SansSerif", Font.PLAIN, 13)
        );

        descriptionLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        JButton feedbackButton = new JButton(
                "Give Feedback"
        );

        feedbackButton.setFont(
                new Font("SansSerif", Font.BOLD, 14)
        );

        feedbackButton.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        feedbackButton.addActionListener(e -> {
            new FeedbackFrame(mealName, feedbackButton);
        });

        card.add(mealLabel);
        card.add(Box.createVerticalStrut(15));
        card.add(descriptionLabel);
        card.add(Box.createVerticalStrut(25));
        card.add(feedbackButton);

        return card;
    }
}