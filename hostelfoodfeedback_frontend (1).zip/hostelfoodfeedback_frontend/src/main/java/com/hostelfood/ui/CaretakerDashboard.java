package com.hostelfood.ui;

import javax.swing.*;
import java.awt.*;

public class CaretakerDashboard extends JFrame {
    public CaretakerDashboard() {
        setTitle("Caretaker Dashboard");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel label = new JLabel("Caretaker Dashboard — Next screen", SwingConstants.CENTER);
        label.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(label);

        setVisible(true);
    }
}
