# Hostel Food Quality Feedback and Rating Management System

Frontend: Java 17 + Swing  
Backend/database will be connected later.

## Current screen
- Login screen
- Student / Committee Leader / Caretaker role selection
- Basic validation
- Demo login routing
- No MySQL/Hibernate logic yet

## Run
```bash
mvn clean compile
mvn exec:java
```

Demo:
- Student ID: `STU001`
- Password: `1234`
- Role: Student

This demo authentication is temporary and will be replaced by backend authentication later.
